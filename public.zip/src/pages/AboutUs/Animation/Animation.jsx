
const Animation = () => {
    return (
        <div className="Animations">
            <div className="wrapper">
                <h1 className="main_text">

                    <span className="span_element">R</span>
                    <span className="span_element">S</span>
                    <span className="span_element">N</span>
                    <span className="span_element">T</span>

                </h1>

            </div>
        </div>
    );
};

export default Animation;