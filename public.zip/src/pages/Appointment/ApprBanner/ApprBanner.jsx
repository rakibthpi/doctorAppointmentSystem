

const ApprBanner = () => {
    return (
        <div className="appointmentBanner">
            <div className="container">
                <div className="appointmentText">
                    <h1>Banner Main area </h1>
                </div>
            </div>
        </div>
    );
};

export default ApprBanner;